
import './App.css'
import FormApi from './Components/FormApi'
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import ShowForm from './Components/ShowForm';

function App() {

  return (
    <>
      <Router>
        <Routes>
          <Route path='/' element={<FormApi />}></Route>
          <Route path='/formdata' element={<ShowForm />}></Route>

        </Routes>
      </Router>
    </>
  )
}

export default App
