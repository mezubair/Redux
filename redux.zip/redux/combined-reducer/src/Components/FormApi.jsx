import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Link } from "react-router-dom";
import Card from './Card';

function FormApi() {
    const [formData, setFormData] = useState({
        name: '',
        email: '',
    });

    const dispatch = useDispatch();


    useEffect(() => {
        async function fetchData() {
            const response = await fetch("https://jsonplaceholder.typicode.com/todos/");
            const data = await response.json();
            dispatch({
                type: "API-DATA",
                payload: data
            })
        }
        fetchData();
    }, [])

    const handleChange = (e) => {
        setFormData({
            ...formData,
            [e.target.name]: e.target.value,
        });


    };

    const handleSubmit = (e) => {
        e.preventDefault();

        dispatch({
            type: 'SUBMIT',
            payload: formData,
        });
        setFormData({
            name: '',
            email: '',
        });
    };

    return (
        <>
            <form onSubmit={handleSubmit}>
                <label htmlFor="name">Name</label>
                <input type="text" name="name" id="name" onChange={handleChange} value={formData.name} />
                <label htmlFor="email">Email</label>
                <input type="email" name="email" onChange={handleChange} value={formData.email} />
                <button type="submit">Submit</button>
            </form>
            <div>

            </div>
            <Link to={"/formdata"}>View Form Data</Link>
            <Card />
        </>
    );
}

export default FormApi;
