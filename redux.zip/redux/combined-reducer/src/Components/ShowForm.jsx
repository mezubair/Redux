import React from 'react'
import { useSelector } from 'react-redux';

function ShowForm() {
    const dataFromStore = useSelector((state) => state.formData);
    return (
        <div>
            <div>
                <h2>form show</h2>
                {dataFromStore.map((item, index) => (
                    <div>
                        <h2 key={index}>{item.name}</h2>
                        <h2 >{item.email}</h2>
                    </div>
                ))}
            </div>
        </div>
    )
}

export default ShowForm
