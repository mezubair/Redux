import { combineReducers, createStore } from 'redux';

const formDataReducer = (state = [], action) => {
  switch (action.type) {
    case 'SUBMIT':
      return [...state, action.payload];
    default:
      return state;
  }
};

const apiReducer = (state = [], action) => {
  switch (action.type) {
    case 'API-DATA':
      return [...state, action.payload];
    default:
      return state;
  }
};

const rootReducer = combineReducers({
  formData: formDataReducer,
  api: apiReducer,
});

const store = createStore(rootReducer);
export default store;
