
import './App.css'
import FormData from './components/FormData'

function App() {
  return (
    <>
      <FormData />
    </>
  )
}

export default App
