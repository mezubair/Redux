import { createStore } from 'redux';

const formDataReducer = (state = [], action) => {
  switch (action.type) {
    case 'SUBMIT':
      return [...state, action.payload];
    default:
      return state;
  }
};

const store = createStore(formDataReducer);
export default store;
