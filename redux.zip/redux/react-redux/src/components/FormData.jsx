import React, { useState } from 'react';
import { useDispatch, useSelector } from "react-redux";

function FormData() {
    const dispatch = useDispatch();
    const dataFromStore = useSelector((state) => state);
    const [formData, setFormData] = useState({
        name: '',
        email: ''
    });

    const handleSubmit = (e) => {
        e.preventDefault();
        console.log(formData);
        setFormData({
            name: '',
            email: ''
        })
        dispatch({
            type: "SUBMIT",
            payload: formData
        });
    };

    const handleChange = (e) => {
        setFormData({
            ...formData,
            [e.target.name]: e.target.value
        });
    };

    return (
        <>
            <div>
                <form onSubmit={handleSubmit}>
                    <label htmlFor="name">Name</label>
                    <input
                        type="text"
                        id="name"
                        name="name"
                        value={formData.name}
                        onChange={handleChange}
                    />
                    <label htmlFor="email">Email</label>
                    <input
                        type="email"
                        id="email"
                        name="email"
                        value={formData.email}
                        onChange={handleChange}
                    />
                    <button type="submit">Submit</button>
                </form>

            </div>
            <div className='show-data'>
                {!dataFromStore ? (
                    <p>no data found</p>
                ) : (
                    dataFromStore.map((item, index) => (
                        <div key={index}>
                            <h2>Name: {item.name}</h2>
                            <h2>Email: {item.email}</h2>
                        </div>
                    ))
                )}
            </div>


        </>
    );
}

export default FormData;
