import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { increment, decrement } from '../features/counterSlice';
import { setData } from '../features/fetchSlice';
import GithbProfile from './GithbProfile';
import FormData from './FormData';

function Counter() {
    const dispatch = useDispatch();
    const count = useSelector((state) => state.counter.value);

    useEffect(() => {
        async function fetchData() {
            try {
                const response = await fetch('https://api.github.com/users/mezubair');
                const data = await response.json();
                dispatch(setData(data));
            } catch (error) {
                console.error('Error fetching data:', error);

            }
        }
        fetchData();
    }, []);

    return (
        <div className='counter-container'>
            <button onClick={() => dispatch(decrement())}>-</button>
            <h1>count: {count}</h1>

            <button onClick={() => dispatch(increment())}>+</button>
            <br />
            <GithbProfile />
            <FormData />
        </div>
    );
}

export default Counter;
