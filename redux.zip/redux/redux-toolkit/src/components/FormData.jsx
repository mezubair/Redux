import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import { getFormData } from '../features/FormSlice';
import ShowFormData from './ShowFormData';


function FormData() {
    const dispatch = useDispatch();
    const [formData, setFormData] = useState({ name: '', email: '' });

    const handleSubmit = (e) => {
        e.preventDefault();
        setFormData({ name: '', email: '' });
        dispatch(getFormData([formData]));
    };

    const handleChange = (e) => {
        setFormData({
            ...formData,
            [e.target.name]: e.target.value,
        });
    };

    return (
        <div>
            <form onSubmit={handleSubmit}>
                <label htmlFor="name">Name</label>
                <input type="text" name="name" value={formData.name} onChange={handleChange} />

                <label htmlFor="email">Email</label>
                <input type="text" name="email" value={formData.email} onChange={handleChange} />

                <button type="submit">Submit</button>
            </form>
            <ShowFormData />
        </div>
    );
}

export default FormData;
