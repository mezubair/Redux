import React from 'react'
import { useSelector } from 'react-redux'

function GithbProfile() {
    const { name, login, avatar_url } = useSelector((state) => state.fetchSlice.value);
    return (
        <>
            <div>
                <h2>Fetched Data:</h2>
                <h2>name: {name}</h2>
                <h2>login: {login}</h2>
                <img src={avatar_url} />
            </div>
        </>
    )
}

export default GithbProfile
