import React from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { deleteFormData } from '../features/FormSlice';
import { AiTwotoneDelete } from "react-icons/ai";

function ShowFormData() {
    const formData = useSelector((state) => state.formData.value);
    const dispatch = useDispatch();

    return (
        <div>
            {formData.map((item, index) => (
                <p key={index}>
                    Name: {item.name}, Email: {item.email}
                    <button onClick={(e) => {
                        dispatch(deleteFormData(item.id))
                    }}><AiTwotoneDelete /></button>
                </p>

            ))}
        </div>
    );
}

export default ShowFormData;
