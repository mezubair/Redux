import { createSlice, nanoid } from '@reduxjs/toolkit';
const initialState = {
  value: [],
};

export const FormSlice = createSlice({
  name: 'formData',
  initialState,
  reducers: {
    getFormData: (state, action) => {
      state.value.push({ id: nanoid(), ...action.payload[0] });
    },
    deleteFormData: (state, action) => {
      state.value = state.value.filter((entry) => entry.id !== action.payload);
    },
  },
});
export const { getFormData, deleteFormData } = FormSlice.actions;
export default FormSlice.reducer;
