import { createSlice } from '@reduxjs/toolkit';

const initialState = {
  value: [],
};

export const fetchSlice = createSlice({
  name: 'fetchSlice',
  initialState,
  reducers: {
    setData: (state, action) => {
      state.value = action.payload;
    },
  },
});

export const { setData } = fetchSlice.actions;

export default fetchSlice.reducer;
