import { configureStore } from '@reduxjs/toolkit';
import counterReducer from '../features/counterSlice';
import fetchReducer from '../features/fetchSlice';
import formDataReducer from '../features/FormSlice';

export const store = configureStore({
  reducer: {
    counter: counterReducer,
    fetchSlice: fetchReducer,
    formData: formDataReducer,
  },
});
